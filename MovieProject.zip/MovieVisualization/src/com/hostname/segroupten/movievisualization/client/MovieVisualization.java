package com.hostname.segroupten.movievisualization.client;
import com.hostname.segroupten.movievisualization.shared.Movie;

import java.util.ArrayList;
import java.util.Arrays;

import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.lang.Number;
import com.google.gwt.cell.client.DateCell;
import com.google.gwt.cell.client.NumberCell;
import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.shared.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.cellview.client.CellTable;
import com.google.gwt.user.cellview.client.Column;
import com.google.gwt.user.cellview.client
.HasKeyboardSelectionPolicy.KeyboardSelectionPolicy;
import com.google.gwt.user.cellview.client.SimplePager;
import com.google.gwt.user.cellview.client.TextColumn;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.PushButton;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.view.client.SelectionChangeEvent;
import com.google.gwt.view.client.SingleSelectionModel;


public class MovieVisualization implements EntryPoint {
   /**
   * A simple data type that represents a contact.
   */

   public class ReleaseDateSort implements Comparator <Movie>{
	   @Override
	   public int compare(Movie movie1, Movie movie2){
		   return movie1.releasedate.compareTo(movie2.releasedate);

	   }
   }

   /**
   * The list of data to display.
   */
   public List<Movie> MOVIES = Arrays.asList(
      new Movie("Lord of the Rings", new Date(80, 4, 2003), "USA", 201, "Institute XY, Zürich, Switzerland"),
      new Movie("Vertigo", new Date(85, 2, 1950), "USA", 109, "Institute XY, Zürich, Switzerland"),
      new Movie("harrypotter",new Date(46, 6, 6),"UK", 60, "Institute XY, Zürich, Switzerland"),
      new Movie("xy", new Date(23,4,6), "Zürich", 90, "Institute XY, Zürich, Switzerland"),
      new Movie("lotr1", new Date(80, 4, 12), "india", 140, "Institute XY, Zürich, Switzerland"),
      new Movie("lotr3", new Date(85, 2, 22), "usa", 90, "Institute XY, Zürich, Switzerland"),
      new Movie("harrypotter",new Date(46, 6, 6),"UK", 60, "Institute XY, Zürich, Switzerland"),
      new Movie("xy", new Date(23,4,6), "Zürich", 90, "Institute XY, Zürich, Switzerland"),
      new Movie("lotr1", new Date(80, 4, 12), "india", 140, "Institute XY, Zürich, Switzerland"),
      new Movie("lotr3", new Date(85, 2, 22), "usa", 90, "Institute XY, Zürich, Switzerland"),
      new Movie("harrypotter",new Date(46, 6, 6),"UK", 60, "Institute XY, Zürich, Switzerland"),
      new Movie("xy", new Date(23,4,6), "Zürich", 90, "Institute XY, Zürich, Switzerland"),
      new Movie("lotr1", new Date(80, 4, 12), "india", 140, "Institute XY, Zürich, Switzerland"),
      new Movie("lotr3", new Date(85, 2, 22), "usa", 90, "Institute XY, Zürich, Switzerland"),
      new Movie("xy", new Date(23,4,6), "Zürich", 90, "Institute XY, Zürich, Switzerland"),
      new Movie("lotr1", new Date(80, 4, 12), "india", 140, "Institute XY, Zürich, Switzerland"),
      new Movie("lotr3", new Date(85, 2, 22), "usa", 90, "Institute XY, Zürich, Switzerland"),
      new Movie("harrypotter",new Date(46, 6, 6),"UK", 60, "Institute XY, Zürich, Switzerland"),
      new Movie("xy", new Date(23,4,6), "Zürich", 90, "Institute XY, Zürich, Switzerland"),
      new Movie("lotr1", new Date(80, 4, 12), "india", 140, "Institute XY, Zürich, Switzerland"),
      new Movie("lotr3", new Date(85, 2, 22), "usa", 90, "Institute XY, Zürich, Switzerland"),
      new Movie("xy", new Date(23,4,6), "Zürich", 90, "Institute XY, Zürich, Switzerland"),
      new Movie("lotr1", new Date(80, 4, 12), "india", 140, "Institute XY, Zürich, Switzerland"),
      new Movie("lotr3", new Date(85, 2, 22), "usa", 90, "Institute XY, Zürich, Switzerland"),
      new Movie("harrypotter",new Date(46, 6, 6),"UK", 60, "Institute XY, Zürich, Switzerland"),
      new Movie("xy", new Date(23,4,6), "Zürich", 90, "Institute XY, Zürich, Switzerland"),
      new Movie("lotr1", new Date(80, 4, 12), "india", 140, "Institute XY, Zürich, Switzerland"),
      new Movie("lotr3", new Date(85, 2, 22), "usa", 90, "Institute XY, Zürich, Switzerland"),
      new Movie("xy", new Date(23,4,6), "Zürich", 90, "Institute XY, Zürich, Switzerland")
		   );

   public void onModuleLoad() {
      // Create a CellTable.
      final CellTable<Movie> table = new CellTable<Movie>();
      table.setKeyboardSelectionPolicy(KeyboardSelectionPolicy.ENABLED);
      table.setVisible(false);
      // Add a text column to show the name.
      TextColumn<Movie> nameColumn = 
      new TextColumn<Movie>() {
         @Override
         public String getValue(Movie object) {
            return object.name;
         }
      };
      table.addColumn(nameColumn, "Movie Name");

      // Add a date column to show the releasdate.
      DateCell dateCell = new DateCell();
      Column<Movie, Date> dateColumn 
      = new Column<Movie, Date>(dateCell) {
         @Override
         public Date getValue(Movie object) {
            return object.releasedate ;
         }
        
      };
      table.addColumn(dateColumn, "Release Date");

      // Add a text column to show the country.
      TextColumn<Movie> countryColumn 
      = new TextColumn<Movie>() {
         @Override
         public String getValue(Movie object) {
            return object.country;
         }
      };
      table.addColumn(countryColumn, "Country");
      
      
      
     Column<Movie, Number> lengthColumn 
      = new Column<Movie,Number>(new NumberCell()){
    	@Override
    	public Integer getValue(Movie movie){
    		return movie.length;
    	}
     };

      //table.addColumn(lengthColumn, "Length");
      
      
      TextColumn<Movie> newlengthColumn 
      = new TextColumn<Movie>() {
         @Override
         public String getValue(Movie object) {
            return object.length + " minutes";
         }
      };
      
      table.addColumn(newlengthColumn, "Length formatted"); 

      // Add a selection model to handle user selection.
      final SingleSelectionModel<Movie> selectionModel 
      = new SingleSelectionModel<Movie>();
      table.setSelectionModel(selectionModel);
      selectionModel.addSelectionChangeHandler(
      new SelectionChangeEvent.Handler() {
         public void onSelectionChange(SelectionChangeEvent event) {
            Movie selected = selectionModel.getSelectedObject();
            if (selected != null) {
               Window.alert(
            		    "the information for " +selected.name+" was provided by \n" + selected.source
            		   
            		   
            		   );
            }
         }
      });
      /*
     ArrayList<Movie> moviesfromdb = new ArrayList<Movie>();
     MovieDatabaseServiceAsync moviesrv = GWT.create(MovieDatabaseService.class);
      AsyncCallback<Movie[]> callback = new AsyncCallback<Movie[]>(){

		@Override
		public void onFailure(Throwable caught) {
			Window.alert("error on loading from serverside MovieDBservice");
			
		}

		@Override
		public void onSuccess(Movie[] result) {
			Window.alert(result[0].country);
			
		}
    	  
      };*/
      
      
      
      
      SimplePager pager = new SimplePager();
     pager.setDisplay(table);
      
     /* TODO implement the function&buttons so that the celltable is updated with the new values of the arraylist
      do this for all the attributes (sortByName, sortByLength etc..) keep in mind that you have to create
      classes for the sorting algorithm (like ReleaseDateSort)
      
      */
      final Button sortByReleaseDate  = new Button ("Sort By Release Date");
      sortByReleaseDate.addClickHandler(new ClickHandler(){
      	@Override
      	public void onClick(ClickEvent event) {
      		Window.alert("sort button was pressed, function not implementde");
      		//this line sorts the arraylist by date
      		Collections.sort(MOVIES, new ReleaseDateSort());
      	  
      	  
          //table.addColumn(nameColumn, "Movie Name");
         // table.addColumn(dateColumn, "Release Date");
         // table.addColumn(countryColumn, "Country");
        //   table.addColumn(lengthColumn, "Length");
      	
      	
      	}
      	
      	
      });
          
 
      
      
final PushButton visibleButton = new PushButton("show celltable!");
      visibleButton.addClickHandler(new ClickHandler(){
		public void onClick(ClickEvent event) {

	if (table.isVisible()){
		table.setVisible(false);
		visibleButton.setText("show celltable!");
	}
	else {
		table.setVisible(true);
		visibleButton.setText("hide celltable!");
	}
			
		}
      });
      
      
      Image image = new Image();
      image.setUrl("ressources/ad-placeholder.jpg");
      
      

      sortByReleaseDate.setStylePrimaryName("gwt-Button");
     
      visibleButton.setStylePrimaryName("gwt-Button");
      // Set the total row count. This isn't strictly necessary,
      // but it affects paging calculations, so its good habit to
      // keep the row count up to date.
      
      table.setRowCount(MOVIES.size(), true);
     // table.setVisibleRange();
      
      // Push the data into the widget.
      
      table.setRowData(0, MOVIES);
      VerticalPanel panel = new VerticalPanel();
      panel.setBorderWidth(1);	    
      panel.setWidth("500");
      panel.add(table);
      panel.add(pager);
      VerticalPanel panel2 = new VerticalPanel();
      panel2.add(image);
      RootPanel.get("adv").add(panel2);
      
      // panel.add(image);
      // Add the widgets to the root panel.
      
      RootPanel.get("buttons").add(visibleButton);
      RootPanel.get("buttons").add(sortByReleaseDate);
      RootPanel.get("gwtContainer").add(panel);
     
   }

private void refreshtable() {
	// TODO Auto-generated method stub
	
	
}
}