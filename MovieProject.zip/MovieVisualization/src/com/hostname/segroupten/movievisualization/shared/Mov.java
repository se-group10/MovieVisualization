package com.hostname.segroupten.movievisualization.shared;

public class Mov {
public  String name;


public Mov(){};
}
